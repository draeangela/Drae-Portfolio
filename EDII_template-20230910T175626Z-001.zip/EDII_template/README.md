# EDII_2324
Materials for EDII 2023-2024

Website url: https://eeriley99.github.io/EDII_2324/

Students:

Brady https://bradywaldron.github.io/EDI/

Ethan https://ethany123.github.io/EDI/

Gracie https://gburraway.github.io/EDI/

Patrick https://midengineer.github.io/EDI/



